create function pg_catalog.interval_pl_timestamp(interval, timestamp without time zone) returns timestamp without time zone
LANGUAGE SQL
AS $$
select $2 + $1
$$;
